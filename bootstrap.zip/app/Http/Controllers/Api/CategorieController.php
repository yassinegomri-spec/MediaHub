<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Categorie;

class CategorieController extends Controller
{
    public function index()
    {
        return response()->json(
            Categorie::withCount('publications')->orderBy('nom')->get()
        );
    }
}