<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCategorieRequest;
use App\Http\Requests\UpdateCategorieRequest;
use App\Models\Categorie;
use Illuminate\Support\Facades\Cache;

class CategorieController extends Controller
{
    public function index()
    {
        $categories = Cache::remember('categories.liste', 3600, function () {
            return Categorie::withCount('publications')
                ->orderBy('nom')
                ->get();
        });

        return view('categories.index', compact('categories'));
    }

    public function create()
    {
        return view('categories.create');
    }

    public function store(StoreCategorieRequest $request)
    {
        Categorie::create($request->validated());
        Cache::forget('categories.liste');

        return redirect()
            ->route('categories.index')
            ->with('succes', 'Catégorie créée avec succès.');
    }

    public function edit(Categorie $categorie)
    {
        return view('categories.edit', compact('categorie'));
    }

    public function update(UpdateCategorieRequest $request, Categorie $categorie)
    {
        $categorie->update($request->validated());
        Cache::forget('categories.liste');

        return redirect()
            ->route('categories.index')
            ->with('succes', 'Catégorie mise à jour avec succès.');
    }

    public function destroy(Categorie $categorie)
    {
        if ($categorie->publications()->withTrashed()->exists()) {
            return redirect()
                ->route('categories.index')
                ->with('erreur', 'Cette catégorie est encore associée à une publication.');
        }

        $categorie->delete();
        Cache::forget('categories.liste');

        return redirect()
            ->route('categories.index')
            ->with('succes', 'Catégorie supprimée avec succès.');
    }
}