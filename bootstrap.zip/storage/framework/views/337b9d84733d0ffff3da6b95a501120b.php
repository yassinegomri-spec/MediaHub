

<?php $__env->startSection('titre', 'Connexion — MediaHub'); ?>

<?php $__env->startSection('contenu'); ?>
    <h1>Connexion à MediaHub</h1>

    <?php echo $__env->make('partials.erreurs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <form class="formulaire" method="POST" action="<?php echo e(route('connexion.store')); ?>">
        <?php echo csrf_field(); ?>

        <div>
            <label for="email">Adresse e-mail</label>
            <input
                id="email"
                name="email"
                type="email"
                value="<?php echo e(old('email')); ?>"
                required
            >
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="erreur-champ"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="password">Mot de passe</label>
            <input
                id="password"
                name="password"
                type="password"
                required
            >
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="erreur-champ"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit">Se connecter</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/auth/connexion.blade.php ENDPATH**/ ?>