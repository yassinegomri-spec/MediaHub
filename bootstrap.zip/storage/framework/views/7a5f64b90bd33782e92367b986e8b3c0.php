<article class="carte <?php echo e($misEnAvant ? 'carte-mise-en-avant' : ''); ?>">
    <?php if($misEnAvant): ?>
        <span class="badge">
            À la une
        </span>
    <?php endif; ?>

    <h2><?php echo e($titre); ?></h2>

    <div class="carte-corps">
        <?php echo e($slot); ?>

    </div>

</article>
<?php /**PATH C:\Users\Admin\MediaHub\resources\views/components/carte.blade.php ENDPATH**/ ?>