

<?php $__env->startSection('titre', 'À propos — MediaHub'); ?>

<?php $__env->startSection(
    'meta_description',
    'Découvrez le projet MediaHub et ses objectifs.'
); ?>

<?php $__env->startSection('contenu'); ?>
    <section class="page-simple">
        <p class="sur-titre">MediaHub</p>

        <h1>À propos de MediaHub</h1>

        <p>
            MediaHub est une plateforme de gestion et de diffusion
            de contenus multimédias.
        </p>

        <p>
            Ce projet est développé dans le cadre du module Laravel
            pour mettre en pratique les routes, contrôleurs et vues Blade.
        </p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/a-propos.blade.php ENDPATH**/ ?>