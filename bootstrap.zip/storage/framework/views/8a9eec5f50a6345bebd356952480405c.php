

<?php $__env->startSection('titre', 'Détail du contenu — MediaHub'); ?>

<?php $__env->startSection('contenu'); ?>
    <h1><?php echo e($contenu->titre); ?></h1>

    <p>
        Catégorie : <?php echo e($contenu->categorie?->nom ?? 'Sans catégorie'); ?>

        Auteur : <?php echo e($contenu->auteur?->name ?? 'Auteur inconnu'); ?>

    </p>

    <div style="white-space: pre-line;"><?php echo e($contenu->contenu); ?></div>

    <?php if($contenu->image): ?>
        <figure>
            <img
                src="<?php echo e($contenu->url_image); ?>"
                alt="<?php echo e($contenu->titre); ?>"
                style="max-width: 100%; height: auto"
            >
        </figure>
    <?php endif; ?>

    <?php if($contenu->type_media === 'audio'): ?>
        <audio
            controls
            src="<?php echo e(\Illuminate\Support\Facades\Storage::url($contenu->fichier_media)); ?>"
        >
            Votre navigateur ne prend pas en charge la lecture audio.
        </audio>
    <?php elseif($contenu->type_media === 'video'): ?>
        <video
            controls
            style="max-width: 100%"
            src="<?php echo e(\Illuminate\Support\Facades\Storage::url($contenu->fichier_media)); ?>"
        >
            Votre navigateur ne prend pas en charge la lecture vidéo.
        </video>
    <?php endif; ?>

    <h2>Commentaires (<?php echo e($contenu->commentaires->count()); ?>)</h2>

    <?php $__empty_1 = true; $__currentLoopData = $contenu->commentaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article>
            <p>
                <strong><?php echo e($commentaire->auteur?->name ?? 'Auteur inconnu'); ?></strong>
            </p>
            <p><?php echo e($commentaire->contenu); ?></p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Aucun commentaire pour le moment.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/contenus/show.blade.php ENDPATH**/ ?>