

<?php $__env->startSection('titre', 'Accueil — MediaHub'); ?>

<?php $__env->startSection(
    'meta_description',
    'Bienvenue sur MediaHub, plateforme de gestion de contenus multimédias.'
); ?>

<?php $__env->startSection('contenu'); ?>
    <section class="hero">
        <p class="sur-titre">Bienvenue sur</p>

        <h1>MediaHub</h1>

        <p class="introduction">
            La plateforme de gestion et de diffusion de contenus multimédias.
        </p>

        <a class="bouton" href="<?php echo e(route('contenus.index')); ?>">
            Découvrir les contenus
        </a>
    </section>

    <section class="section-accueil">
        <h2>Une plateforme multimédia</h2>

        <p>
            MediaHub permet de découvrir, organiser et diffuser
            différents types de contenus multimédias.
        </p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/accueil.blade.php ENDPATH**/ ?>