

<?php $__env->startSection('titre', 'Créer une publication — MediaHub'); ?>

<?php $__env->startSection('contenu'); ?>
    <h1 class="titre-formulaire">Créer une publication</h1>
    <h1 class="titre-formulaire">Modifier la publication</h1>
    <?php echo $__env->make('partials.erreurs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <form
        class="formulaire-publication"
        novalidate
        method="POST"
        action="<?php echo e(route('contenus.store')); ?>"
        enctype="multipart/form-data"
    >
        <?php echo csrf_field(); ?>

        <div>
            <label for="titre">Titre</label>
            <input
                id="titre"
                name="titre"
                type="text"
                value="<?php echo e(old('titre')); ?>"
                required
            >
            <?php $__errorArgs = ['titre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="erreur-champ"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="categorie_id">Catégorie</label>
            <select id="categorie_id" name="categorie_id" required>
                <option value="">Choisir une catégorie</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        value="<?php echo e($categorie->id); ?>"
                        <?php if(old('categorie_id') == $categorie->id): echo 'selected'; endif; ?>
                    >
                        <?php echo e($categorie->nom); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['categorie_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="erreur-champ"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="contenu">Contenu</label>
            <textarea
                id="contenu"
                name="contenu"
                rows="10"
                required
            ><?php echo e(old('contenu')); ?></textarea>
            <?php $__errorArgs = ['contenu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="erreur-champ"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="image">Image — 2 Mo maximum</label>
            <input
                id="image"
                name="image"
                type="file"
                accept="image/*"
            >
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="erreur-champ"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="fichier_media">
                Fichier audio ou vidéo — 20 Mo maximum
            </label>
            <input
                id="fichier_media"
                name="fichier_media"
                type="file"
                accept="audio/*,video/*"
            >
            <?php $__errorArgs = ['fichier_media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="erreur-champ"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit">Publier</button>
        <a href="<?php echo e(route('contenus.index')); ?>">Annuler</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/contenus/create.blade.php ENDPATH**/ ?>