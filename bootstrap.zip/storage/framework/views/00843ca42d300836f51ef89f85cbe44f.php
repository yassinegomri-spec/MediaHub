<nav class="navigation">
    <div class="navigation-interne">
        <a class="logo" href="<?php echo e(route('accueil')); ?>">
            MediaHub
        </a>

        <div class="liens-navigation">
            <a href="<?php echo e(route('accueil')); ?>">
                Accueil
            </a>

            <a href="<?php echo e(route('contenus.index')); ?>">
                Contenus
            </a>

            <a href="<?php echo e(route('a-propos')); ?>">
                À propos
            </a>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>">Connexion</a>
                <a href="<?php echo e(route('inscription')); ?>">Inscription</a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <form method="POST" action="<?php echo e(route('deconnexion')); ?>">
             <?php echo csrf_field(); ?>
                <button type="submit">Déconnexion</button>
                </form>
<?php endif; ?>

        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Admin\MediaHub\resources\views/partials/navigation.blade.php ENDPATH**/ ?>