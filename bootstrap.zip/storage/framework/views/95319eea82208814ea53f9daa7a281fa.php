

<?php $__env->startSection('titre', 'Contenus — MediaHub'); ?>

<?php $__env->startSection('meta_description', 'Découvrez les contenus multimédias disponibles sur MediaHub.'); ?>

<?php $__env->startSection('contenu'); ?>
    <section class="page-contenus">
        <div class="entete-page">
            <p class="sur-titre">MediaHub</p>

            <h1>Contenus multimédias</h1>

            <p>
                Découvrez les dernières publications disponibles.
                Tri actuel : <strong><?php echo e($tri); ?></strong>
            </p>
        </div>

        
        <?php if(auth()->guard()->check()): ?>
            <p>
                <a class="bouton" href="<?php echo e(route('contenus.create')); ?>">
                    Créer une publication
                </a>
            </p>
        <?php else: ?>
            <p>
                <a class="bouton" href="<?php echo e(route('login')); ?>">
                    Connectez-vous pour créer une publication
                </a>
            </p>
        <?php endif; ?>

        <div class="grille-contenus">
            <?php $__empty_1 = true; $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if (isset($component)) { $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $attributes; } ?>
<?php $component = App\View\Components\Carte::resolve(['titre' => $publication->titre] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Carte::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <p>
                        <?php echo e(\Illuminate\Support\Str::limit($publication->contenu, 180)); ?>

                    </p>

                    <p>
                        Catégorie :
                        <?php echo e($publication->categorie?->nom ?? 'Sans catégorie'); ?>


                        Auteur :
                        <?php echo e($publication->auteur?->name ?? 'Auteur inconnu'); ?>


                        Commentaires :
                        <?php echo e($publication->commentaires_count); ?>

                    </p>

                    <div class="actions-crud">
                        <a
                            class="lien-carte"
                            href="<?php echo e(route('contenus.show', $publication)); ?>"
                        >
                            Voir le contenu
                        </a>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $publication)): ?>
                            <a
                                class="lien-carte"
                                href="<?php echo e(route('contenus.edit', $publication)); ?>"
                            >
                                Modifier
                            </a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $publication)): ?>
                            <form
                                method="POST"
                                action="<?php echo e(route('contenus.destroy', $publication)); ?>"
                            >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit">
                                    Supprimer
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $attributes = $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $component = $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="message-vide">
                    Aucune publication disponible pour le moment.
                </p>
            <?php endif; ?>
        </div>

        <?php echo e($publications->links()); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Admin\MediaHub\resources\views/contenus/index.blade.php ENDPATH**/ ?>