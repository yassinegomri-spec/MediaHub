<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('titre', 'MediaHub'); ?></title>

    <meta
        name="description"
        content="<?php echo $__env->yieldContent('meta_description', 'MediaHub, plateforme de contenus multimédias'); ?>"
    >

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>

    <?php echo $__env->make('partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="conteneur">
        <?php if(session('succes')): ?>
    <div class="alerte alerte-succes">
        <?php echo e(session('succes')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('erreur')): ?>
    <div class="alerte alerte-erreur">
        <?php echo e(session('erreur')); ?>

    </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('contenu'); ?>

    <?php echo $__env->make('partials.pied-de-page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Admin\MediaHub\resources\views/layouts/app.blade.php ENDPATH**/ ?>