<footer class="pied-de-page">
    <p>
        &copy; <?php echo e(date('Y')); ?> MediaHub — Tous droits réservés.
    </p>
</footer>
<?php /**PATH C:\Users\Admin\MediaHub\resources\views/partials/pied-de-page.blade.php ENDPATH**/ ?>