@extends('layouts.app')

@section('titre', 'Inscription — MediaHub')

@section('contenu')
    <h1>Créer un compte MediaHub</h1>

    @include('partials.erreurs')

    <form method="POST" action="{{ route('inscription.store') }}">
        @csrf

        <label for="name">Nom</label>
        <input id="name" name="name" value="{{ old('name') }}" required>
        @error('name') <p>{{ $message }}</p> @enderror

        <label for="email">Adresse e-mail</label>
        <input id="email" name="email" type="email"
               value="{{ old('email') }}" required>
        @error('email') <p>{{ $message }}</p> @enderror

        <label for="password">Mot de passe</label>
        <input id="password" name="password" type="password" required>
        @error('password') <p>{{ $message }}</p> @enderror

        <label for="password_confirmation">Confirmer le mot de passe</label>
        <input id="password_confirmation" name="password_confirmation"
               type="password" required>

        <button type="submit">Créer mon compte</button>
    </form>
@endsection
