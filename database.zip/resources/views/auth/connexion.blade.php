@extends('layouts.app')

@section('titre', 'Connexion — MediaHub')

@section('contenu')
    <h1>Connexion à MediaHub</h1>

    @include('partials.erreurs')

    <form method="POST" action="{{ route('connexion.store') }}">
        @csrf

        <label for="email">Adresse e-mail</label>
        <input id="email" name="email" type="email"
               value="{{ old('email') }}" required>
        @error('email') <p>{{ $message }}</p> @enderror

        <label for="password">Mot de passe</label>
        <input id="password" name="password" type="password" required>
        @error('password') <p>{{ $message }}</p> @enderror

        <button type="submit">Se connecter</button>
    </form>
@endsection
